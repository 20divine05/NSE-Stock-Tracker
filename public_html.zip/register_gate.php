<?php
require_once __DIR__ . '/config.php';

// Anti-cache
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

// Must have single-use view flag
if (empty($_SESSION['reg_view_once'])) {
    header('Location: register_key.php');
    exit;
}

// CONSUME the flag so another click requires key again
unset($_SESSION['reg_view_once']);

$file = realpath(__DIR__ . '/register.html');
if (!$file || strpos($file, __DIR__) !== 0 || !is_file($file)) {
    http_response_code(404);
    exit('register.html not found');
}

header('Content-Type: text/html; charset=utf-8');
readfile($file);
