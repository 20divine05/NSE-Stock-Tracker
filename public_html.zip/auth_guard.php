<?php // auth_guard.php — include this to 
require_once __DIR__ . '/config.php'; // starts session 
if (empty($_SESSION['user_id'])) 
  { header('Location: index.html'); // 
 exit; }