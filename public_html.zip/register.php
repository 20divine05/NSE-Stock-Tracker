<?php
require_once __DIR__ . '/config.php';

// Require the single-use POST flag; if missing, force secret key page
if (empty($_SESSION['reg_post_once'])) {
    header('Location: register_key.php');
    exit;
}

// Anti-cache (optional but recommended)
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        header('Location: register.html');
        exit;
    }

    // CONSUME the flag now so the form cannot be reposted without key
    unset($_SESSION['reg_post_once']);

    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username === '' || $password === '') {
        die("Username and password are required. <a href='register_key.php'>Go back</a>");
    }
    if (strlen($password) < 6) {
        die("Password must be at least 6 characters. <a href='register_key.php'>Go back</a>");
    }

    // duplicate check
    $stmt = $mysqli->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->close();
        die("Username already taken. <a href='register_key.php'>Choose another</a>");
    }
    $stmt->close();

    // insert user (hashed password)
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $mysqli->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $hash);
    $stmt->execute();
    $stmt->close();

    header("Location: index.html?registered=1");
    exit;

} catch (Throwable $e) {
    error_log("register.php error: " . $e->getMessage());
    http_response_code(500);
    die("Internal error while registering. Please try again later.");
}
