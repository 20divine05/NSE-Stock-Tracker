<?php
require_once 'config.php';

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        header('Location: index.html');
        exit;
    }

    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    if ($username === '' || $password === '') {
        die("Username and password are required. <a href='index.html'>Go back</a>");
    }

    $stmt = $mysqli->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($uid, $hash);

    if ($stmt->fetch() && password_verify($password, $hash)) {
        $stmt->close();

        // Important: rotate session ID on login
        session_regenerate_id(true);
        $_SESSION['user_id']  = $uid;
        $_SESSION['username'] = $username;

        // Anti-cache on the redirecting response (belt-and-braces)
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');

        header('Location: front.html');
        exit;
    }

    $stmt->close();
    die("Invalid credentials. <a href='index.html'>Try again</a>");

} catch (Throwable $e) {
    error_log("in.php error: " . $e->getMessage());
    http_response_code(500);
    echo "Login error.";
}
