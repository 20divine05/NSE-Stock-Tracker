<?php
require_once __DIR__ . '/config.php';

// Anti-cache
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $key = trim($_POST['secret'] ?? '');
    if (hash_equals(REGISTER_SECRET, $key)) {
        // Set single-use flags: one view + one post
        $_SESSION['reg_view_once'] = true;
        $_SESSION['reg_post_once'] = true;
        header('Location: register.html');
        exit;
    } else {
        $msg = 'Invalid secret key.';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Enter Secret Key</title>
  <style>
    :root{--bg:#0f1724;--muted:#94a3b8;--accent:#06b6d4}
    *{box-sizing:border-box;font-family:Inter,system-ui,Segoe UI,Roboto,"Helvetica Neue",Arial}
    html,body{height:100%}
    body{margin:0;background:linear-gradient(180deg,#071022,#07162a);color:#e6eef6;display:flex;align-items:center;justify-content:center;padding:24px}
    .wrap{width:100%;max-width:520px}
    h1{font-size:22px;margin:0 0 6px}
    p.lead{color:var(--muted);margin:0 0 14px;font-size:14px}
    .card{background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));padding:18px;border-radius:12px;box-shadow:0 6px 20px rgba(2,6,23,0.6)}
    form{display:grid;grid-template-columns:1fr;gap:12px;margin-top:6px}
    label{display:block;font-size:12px;color:var(--muted);margin-bottom:6px}
    input,button{font-family:inherit}
    input{width:100%;padding:12px;border-radius:10px;border:1px solid rgba(255,255,255,0.07);background:transparent;color:inherit}
    button{background:var(--accent);color:#022;border:0;padding:12px 16px;border-radius:10px;cursor:pointer;font-weight:700}
    .err{color:#fca5a5;font-size:13px;min-height:18px}
    a.btn{display:inline-flex;gap:8px;padding:10px 14px;border:1px solid rgba(255,255,255,.1);border-radius:10px;color:#cfe6ff;text-decoration:none}
  </style>
</head>
<body>
  <div class="wrap">
    <h1>Enter secret key</h1>
    <p class="lead">Only users with the key can register.</p>

    <div class="card">
      <?php if ($msg): ?><div class="err"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
      <form method="post" autocomplete="off">
        <div>
          <label>Secret key</label>
          <input type="password" name="secret" required />
        </div>
        <button type="submit">Continue to Sign Up</button>
      </form>
      <p style="margin-top:12px"><a class="btn" href="index.html">← Back to Login</a></p>
    </div>
  </div>
</body>
</html>
