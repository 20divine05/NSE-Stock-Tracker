<?php
// front_gate.php — serve specific static HTML files *after* auth check
require_once __DIR__ . '/auth_guard.php'; // applies session check + anti-cache

// Only these HTML files are allowed through the gate (same folder)
$ALLOWED_HTML = [
  'front.html',
  'ohlc.html',
];

$reqPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '';
$reqFile = basename($reqPath); // e.g., "ohlc.html"

// Not allowed → 404
if (!in_array($reqFile, $ALLOWED_HTML, true)) {
    http_response_code(404);
    exit('Not found.');
}

$file = realpath(__DIR__ . DIRECTORY_SEPARATOR . $reqFile);

// Final safety checks
if (!$file || strpos($file, __DIR__) !== 0 || !is_file($file)) {
    http_response_code(404);
    exit('Not found.');
}

// Extra anti-cache (defense-in-depth)
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

header('Content-Type: text/html; charset=utf-8');
readfile($file);
