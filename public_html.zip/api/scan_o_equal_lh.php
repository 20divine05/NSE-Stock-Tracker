<?php
// api/scan_o_equal_lh.php
// Scan NIFTY options around ATM and report strikes where O=Low or O=High for the day.
// Inputs (POST):
//   token     = Upstox access token (required)
//   date      = YYYY-MM-DD (optional, default: today IST)
//   expiry    = YYYY-MM-DD (required)  <-- options expiry
//   steps     = integer (optional, default 5)  # strikes above and below ATM
//   step      = integer (optional, default 50) # strike interval for NIFTY, adjust if needed (e.g., 100 for BankNifty)
//   symbol    = "NIFTY" (default) or "BANKNIFTY" etc. (must be OPTIDX root supported by Upstox)
// Output: JSON with matches and diagnostics.

declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
date_default_timezone_set('Asia/Kolkata');

function bad($code, $msg, $extra = []) {
  http_response_code($code);
  echo json_encode(['error'=>$msg] + $extra, JSON_UNESCAPED_SLASHES);
  exit;
}

$token  = $_POST['token']  ?? '';
$expiry = $_POST['expiry'] ?? '';
if (!$token)  bad(400, 'token missing');
if (!$expiry || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $expiry)) bad(400, 'expiry missing or bad format (YYYY-MM-DD)');

$symbol = $_POST['symbol'] ?? 'NIFTY';
$steps  = isset($_POST['steps']) ? max(0, (int)$_POST['steps']) : 5;
$step   = isset($_POST['step'])  ? max(1, (int)$_POST['step'])  : 50;

$todayIST = (new DateTime('now', new DateTimeZone('Asia/Kolkata')))->format('Y-m-d');
$date = $_POST['date'] ?? $todayIST;
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) bad(400, 'bad date format (YYYY-MM-DD)');

// ---- helpers ----
function http_get_json(string $url, string $token) {
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_HTTPHEADER     => ["Accept: application/json", "Authorization: Bearer $token"],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 30,
  ]);
  $resp = curl_exec($ch);
  $err  = curl_error($ch);
  $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  if ($resp === false) bad(502, 'curl failed', ['detail'=>$err, 'url'=>$url]);
  if ($code < 200 || $code >= 300) bad(502, 'upstream http '.$code, ['body'=>substr($resp,0,600), 'url'=>$url]);
  $j = json_decode($resp, true);
  if (!is_array($j)) bad(502, 'bad json from upstream', ['url'=>$url]);
  return $j;
}

function ts_to_ist_hm(string $isoUtc): string {
  try {
    $dt = new DateTime($isoUtc, new DateTimeZone('UTC'));
    $dt->setTimezone(new DateTimeZone('Asia/Kolkata'));
    return $dt->format('H:i');
  } catch (Throwable $e) { return ''; }
}

function candles_pick_open_0915_and_day_hilo(array $candles): array {
  // Upstox format: [ts, open, high, low, close, volume]
  if (empty($candles)) return [null, null, null, 'no candles'];
  usort($candles, fn($a,$b)=>strcmp((string)$a[0], (string)$b[0]));
  $open0915 = null; $pickedTs = null;
  $dayLow = INF; $dayHigh = -INF;

  foreach ($candles as $c) {
    if (!isset($c[0], $c[1], $c[2], $c[3])) continue;
    $o = (float)$c[1]; $h = (float)$c[2]; $l = (float)$c[3];
    if ($l < $dayLow)  $dayLow  = $l;
    if ($h > $dayHigh) $dayHigh = $h;
    if ($open0915 === null) {
      $hm = ts_to_ist_hm((string)$c[0]);
      if ($hm === '09:15' || $hm > '09:15') { $open0915 = $o; $pickedTs = (string)$c[0]; }
    }
  }
  if ($dayLow === INF)  $dayLow = null;
  if ($dayHigh === -INF) $dayHigh = null;
  return [$open0915, $dayLow, $dayHigh, $pickedTs];
}

function round_to_step(float $val, int $step): int {
  // nearest strike by step
  return (int)(round($val / $step) * $step);
}

// ---- 1) Get NIFTY spot 09:15 open to determine ATM ----
$index_instr = rawurlencode($symbol === 'BANKNIFTY' ? 'NSE_INDEX|Nifty Bank' : 'NSE_INDEX|Nifty 50');
$url_index = "https://api.upstox.com/v3/historical-candle/intraday/$index_instr/minutes/1?from_date=$date&to_date=$date";
$j_index = http_get_json($url_index, $token);
$dataIdx = $j_index['data'] ?? null;
$rawIdx = is_array($dataIdx) ? ($dataIdx['candles'] ?? ($dataIdx['candle'] ?? [])) : [];
[$idxOpen0915, $idxLow, $idxHigh, $idxTs] = candles_pick_open_0915_and_day_hilo($rawIdx);
if ($idxOpen0915 === null) bad(400, 'no index 09:15 open found', ['date'=>$date, 'symbol'=>$symbol]);

$atm = round_to_step((float)$idxOpen0915, $step);

// ---- 2) Build strike list around ATM ----
$strikes = [];
for ($k = -$steps; $k <= $steps; $k++) {
  $strikes[] = $atm + $k * $step;
}

// ---- 3) For each strike and side (CE/PE), fetch day candles and test O=Low / O=High ----
$matches = ['CE'=>['O=Low'=>[], 'O=High'=>[]], 'PE'=>['O=Low'=>[], 'O=High'=>[]]];
$diagnostics = ['date'=>$date, 'symbol'=>$symbol, 'expiry'=>$expiry, 'atm'=>$atm, 'idx_open_0915'=>$idxOpen0915, 'idx_ts'=>$idxTs, 'step'=>$step, 'steps'=>$steps];

$$EPS = isset($_POST['eps']) ? max(0.0, floatval($_POST['eps'])) : 0.05; // tolerance for O≈Low/High


// float tolerance

foreach (['CE','PE'] as $side) {
  foreach ($strikes as $sp) {
    // Upstox v3 option instrument_key: NSE_FO|OPTIDX|NIFTY|YYYY-MM-DD|<strike>|CE/PE
    $ik = rawurlencode("NSE_FO|OPTIDX|$symbol|$expiry|$sp|$side");
    $url_opt = "https://api.upstox.com/v3/historical-candle/intraday/$ik/minutes/1?from_date=$date&to_date=$date";
    $j_opt = http_get_json($url_opt, $token);
    $data = $j_opt['data'] ?? null;
    $raw  = is_array($data) ? ($data['candles'] ?? ($data['candle'] ?? [])) : [];
    [$o915, $dLow, $dHigh, $optTs] = candles_pick_open_0915_and_day_hilo($raw);
    if ($o915 === null || $dLow === null || $dHigh === null) continue;

    $isOL = (abs($o915 - $dLow)  <= $EPS);
    $isOH = (abs($o915 - $dHigh) <= $EPS);

    if ($isOL) $matches[$side]['O=Low'][]   = ['strike'=>$sp, 'open_0915'=>$o915, 'day_low'=>$dLow,  'ts'=>$optTs];
    if ($isOH) $matches[$side]['O=High'][]  = ['strike'=>$sp, 'open_0915'=>$o915, 'day_high'=>$dHigh,'ts'=>$optTs];
  }
}

// ---- 4) Output ----
echo json_encode([
  'diagnostics' => $diagnostics,
  'results' => $matches
], JSON_UNESCAPED_SLASHES);
