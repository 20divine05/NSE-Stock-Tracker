<?php
// api/ohlc.php — Return *today's* hourly OHLC candles for a given instrument_key (Upstox).
// Input (POST, x-www-form-urlencoded):
//   token: Bearer access token (required)
//   instrument_key: e.g. "NSE_FO|12345" (required)
// Output (application/json):
//   { candles: [ { ts, open, high, low, close }, ... ] }

declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

// ---- Validate input ----
$token = $_POST['token'] ?? '';
$ik    = $_POST['instrument_key'] ?? '';
if (!$token) { http_response_code(400); echo json_encode(['error'=>'token missing']); exit; }
if (!$ik)    { http_response_code(400); echo json_encode(['error'=>'instrument_key required']); exit; }

$ikEnc = rawurlencode($ik);
$today = gmdate('Y-m-d'); // use UTC date window like the Python version
$url = "https://api.upstox.com/v3/historical-candle/intraday/$ikEnc/hours/1?from_date=$today&to_date=$today";

// ---- HTTP GET helper ----
$ch = curl_init($url);
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_TIMEOUT        => 30,
  CURLOPT_CONNECTTIMEOUT => 15,
  CURLOPT_SSL_VERIFYPEER => true,
  CURLOPT_HTTPHEADER     => [
    'Accept: application/json',
    "Authorization: Bearer $token"
  ]
]);
$resp = curl_exec($ch);
$http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err  = curl_error($ch);
curl_close($ch);

if ($resp === false) {
  http_response_code(502);
  echo json_encode(['error' => "curl error: $err"]); exit;
}
if ($http < 200 || $http >= 300) {
  http_response_code($http ?: 500);
  echo json_encode(['error' => "upstream status $http", 'body' => $resp]); exit;
}

// ---- Parse JSON and normalize candles ----
$j = json_decode($resp, true);
if (!is_array($j)) {
  http_response_code(502);
  echo json_encode(['error'=>'bad json from upstream']); exit;
}
$data = $j['data'] ?? null;
$candles = [];
if (is_array($data)) {
  $raw = $data['candles'] ?? ($data['candle'] ?? []);
  if (is_array($raw)) {
    foreach ($raw as $c) {
      // Expect [ts, open, high, low, close, volume]
      $candles[] = [
        'ts'    => $c[0] ?? null,
        'open'  => isset($c[1]) ? (float)$c[1] : null,
        'high'  => isset($c[2]) ? (float)$c[2] : null,
        'low'   => isset($c[3]) ? (float)$c[3] : null,
        'close' => isset($c[4]) ? (float)$c[4] : null
      ];
    }
  }
}
// Sort by timestamp string (ISO8601 sorts lexicographically)
usort($candles, function($a,$b){
  return strcmp((string)($a['ts'] ?? ''), (string)($b['ts'] ?? ''));
});

echo json_encode(['candles'=>$candles], JSON_UNESCAPED_SLASHES);
