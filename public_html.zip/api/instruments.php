<?php
// /api/instruments.php — Return option instruments for a given expiry (Upstox instruments JSON).
// Input (GET):
//   expiry=YYYY-MM-DD (required)
//   symbol=NIFTY|BANKNIFTY|... (optional, default NIFTY)
//   nocache=1 (optional) bypass local cache
// Output: { source:"cache"|"network", data:[ {strike:int,type:"CE"|"PE",key:string}, ... ], warning?:string, error?:string }

declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

// --------- Input validation ---------
$expiry = isset($_GET['expiry']) ? (string)$_GET['expiry'] : '';
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $expiry)) {
  http_response_code(400);
  echo json_encode(['error' => 'bad expiry format (YYYY-MM-DD)']); exit;
}
$underlying = strtoupper(trim(isset($_GET['symbol']) ? (string)$_GET['symbol'] : 'NIFTY'));
$nocache    = isset($_GET['nocache']);
$debug      = isset($_GET['debug']);

$URLS = [
  'https://assets.upstox.com/market-quote/instruments/exchange/NSE.json.gz',
  'https://assets.upstox.com/instruments/exchange/NSE.json.gz',
];

$cacheDir  = __DIR__ . '/.cache';
$cacheFile = $cacheDir . '/NSE.json.gz';
$cacheTTL  = 6 * 60 * 60; // 6 hours

if (!is_dir($cacheDir)) { @mkdir($cacheDir, 0777, true); }

function load_from_cache($file, $ttl) {
  if (file_exists($file) && (time() - filemtime($file) < $ttl)) {
    $data = @file_get_contents($file);
    if ($data !== false) return $data;
  }
  return null;
}

function save_cache($file, $data) {
  @file_put_contents($file, $data);
}

function download_first($urls) {
  foreach ($urls as $u) {
    $ch = curl_init($u);
    curl_setopt_array($ch, [
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_TIMEOUT        => 60,
      CURLOPT_HTTPHEADER     => ['Accept: */*','User-Agent: instruments-php/2.0'],
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    if ($body !== false && $code >= 200 && $code < 300) return [$body, null];
    $lastErr = $err ? $err : ("HTTP " . $code);
  }
  return [null, isset($lastErr) ? $lastErr : 'all sources failed'];
}

function ungzip_json($gzBytes) {
  // Some hosts disable gzdecode; fall back to zlib.inflate if needed
  if (function_exists('gzdecode')) {
    $json = @gzdecode($gzBytes);
    if ($json !== false) return $json;
  }
  // Fallback
  $json = @gzinflate(substr($gzBytes, 10));
  return $json !== false ? $json : null;
}

// --------- Load instruments (cache/network) ---------
$source = 'network';
$gz = null;
$warning = null;

if (!$nocache) {
  $cached = load_from_cache($cacheFile, $cacheTTL);
  if ($cached !== null) { $gz = $cached; $source = 'cache'; }
}
if ($gz === null) {
  list($body, $err) = download_first($URLS);
  if ($body === null) {
    http_response_code(502);
    echo json_encode(['error' => 'download failed', 'detail' => $err]); exit;
  }
  $gz = $body;
  save_cache($cacheFile, $gz);
}

$json = ungzip_json($gz);
if ($json === null) {
  http_response_code(502);
  echo json_encode(['error' => 'gzip decode failed']); exit;
}
$doc = json_decode($json, true);
if (!is_array($doc)) {
  http_response_code(502);
  echo json_encode(['error' => 'bad JSON from instruments']); exit;
}

$rows = isset($doc['data']) && is_array($doc['data']) ? $doc['data'] : $doc;

// --------- Filter like 1.py (strict, with fallbacks) ---------
$out = [];
foreach ($rows as $r) {
  // Read fields with defensive fallbacks
  $segment = isset($r['segment']) ? (string)$r['segment'] : '';
  $itype   = isset($r['instrument_type']) ? (string)$r['instrument_type'] :
             (isset($r['instrumentType']) ? (string)$r['instrumentType'] :
             (isset($r['type']) ? (string)$r['type'] : ''));
  $under   = isset($r['underlying_symbol']) ? (string)$r['underlying_symbol'] :
             (isset($r['underlyingSymbol']) ? (string)$r['underlyingSymbol'] : '');
  $tsym    = isset($r['tradingsymbol']) ? (string)$r['tradingsymbol'] :
             (isset($r['trading_symbol']) ? (string)$r['trading_symbol'] :
             (isset($r['symbol']) ? (string)$r['symbol'] : ''));
  $name    = isset($r['name']) ? (string)$r['name'] : '';

  // Must be index options (CE/PE) in F&O
  if ($segment !== 'NSE_FO') continue;
  if ($itype !== 'CE' && $itype !== 'PE') continue;

  // Underlying match: prefer exact underlying_symbol, fallback to prefix in tradingsymbol/name
  $matchUnderlying = false;
  if ($under !== '') {
    $matchUnderlying = (strtoupper($under) === $underlying);
  } else {
    if (preg_match('/^'.preg_quote($underlying, '/').'/i', $tsym) || stripos($name, $underlying) !== false) {
      $matchUnderlying = true;
    }
  }
  if (!$matchUnderlying) continue;

  // Normalize expiry
  $hasExp = (isset($r['expiry']) || isset($r['expiry_date']) || isset($r['expiryDate']));
  if (!$hasExp) continue;
  $expRaw = isset($r['expiry']) ? $r['expiry'] : (isset($r['expiry_date']) ? $r['expiry_date'] : $r['expiryDate']);
  if (is_numeric($expRaw)) {
    $expIso = gmdate('Y-m-d', (int)$expRaw / 1000);
  } else {
    $ts = @strtotime(str_replace('Z','+00:00',(string)$expRaw));
    if ($ts === false) continue;
    $expIso = gmdate('Y-m-d', $ts);
  }
  if ($expIso !== $expiry) continue;

  // Strike and key
  $strike = isset($r['strike_price']) ? $r['strike_price'] :
            (isset($r['strike']) ? $r['strike'] :
            (isset($r['strikePrice']) ? $r['strikePrice'] : null));
  $ikey   = isset($r['instrument_key']) ? $r['instrument_key'] :
            (isset($r['instrumentKey']) ? $r['instrumentKey'] : null);
  if ($strike === null || $ikey === null) continue;

  $out[] = ['strike' => (int)$strike, 'type' => $itype, 'key' => $ikey];
}

// Sort by strike asc
usort($out, function($a,$b){ return $a['strike'] <=> $b['strike']; });

$resp = ['source' => $source, 'data' => $out];
if ($warning) $resp['warning'] = $warning;

echo json_encode($resp, JSON_UNESCAPED_SLASHES);
