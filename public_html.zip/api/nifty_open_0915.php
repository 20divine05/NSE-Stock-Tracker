<?php
// api/nifty_open_0915.php — Get NIFTY spot 09:15 open (IST) for a given date (default: today).
// Input (POST): token (required), date=YYYY-MM-DD (optional)
// Output: { open: float|null, ts_used?: string, note?: string, error?: string }

declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

// Always work in IST locally, but treat API timestamps as UTC.
date_default_timezone_set('Asia/Kolkata');

// --------- Inputs ----------
$token = $_POST['token'] ?? '';
if (!$token) { http_response_code(400); echo json_encode(['error'=>'token missing']); exit; }

$reqDate = $_POST['date'] ?? '';
if ($reqDate !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $reqDate)) {
  http_response_code(400); echo json_encode(['error'=>'bad date format (YYYY-MM-DD)']); exit;
}

// Use *local IST* “today” by default (gmdate can shift at 00:00 UTC and miss today’s file)
$todayIST = (new DateTime('now', new DateTimeZone('Asia/Kolkata')))->format('Y-m-d');
$date = $reqDate ?: $todayIST;

// --------- Build request ----------
$instr = rawurlencode('NSE_INDEX|Nifty 50');
// Upstox intraday 1-minute for the date range [date, date]
$url = "https://api.upstox.com/v3/historical-candle/intraday/$instr/minutes/1?from_date=$date&to_date=$date";

// --------- HTTP GET ----------
$ch = curl_init($url);
curl_setopt_array($ch, [
  CURLOPT_HTTPHEADER      => ["Accept: application/json", "Authorization: Bearer $token"],
  CURLOPT_RETURNTRANSFER  => true,
  CURLOPT_TIMEOUT         => 25,
]);
$resp = curl_exec($ch);
$curlErr = curl_error($ch);
$httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($resp === false) { http_response_code(502); echo json_encode(['error'=>'curl failed','detail'=>$curlErr]); exit; }
if ($httpCode < 200 || $httpCode >= 300) {
  http_response_code(502);
  echo json_encode(['error'=>'upstream http '.$httpCode, 'body'=>substr($resp,0,800)]);
  exit;
}

$j = json_decode($resp, true);
if (!is_array($j)) { http_response_code(502); echo json_encode(['error'=>'bad json from upstream']); exit; }

$data = $j['data'] ?? null;
if (!is_array($data)) { echo json_encode(['open'=>null, 'note'=>'no data field']); exit; }

// Upstox sometimes uses "candle" vs "candles"
$raw = $data['candles'] ?? ($data['candle'] ?? []);
if (!is_array($raw) || empty($raw)) {
  echo json_encode(['open'=>null, 'note'=>'no candles in response']); exit;
}

// Normalise and sort by timestamp.
// Candle format: [ts, open, high, low, close, volume] with ts as ISO8601 UTC (e.g. 2025-10-24T03:45:00Z)
$candles = [];
foreach ($raw as $c) {
  if (!isset($c[0])) continue;
  $ts = (string)$c[0];
  $open = isset($c[1]) ? (float)$c[1] : null;
  $candles[] = ['ts'=>$ts, 'open'=>$open];
}
usort($candles, function($a,$b){ return strcmp($a['ts'],$b['ts']); });

// Helper: parse upstream UTC ts to a DateTime in IST for comparison
function ts_to_ist_hm(string $isoUtc): string {
  try {
    $dt = new DateTime($isoUtc, new DateTimeZone('UTC'));
    $dt->setTimezone(new DateTimeZone('Asia/Kolkata'));
    return $dt->format('H:i');
  } catch (Throwable $e) { return ''; }
}

// Find the exact 09:15 IST candle; if missing, take the first candle >= 09:15 IST.
$pick = null; $ts_used = null;
foreach ($candles as $c) {
  $hm = ts_to_ist_hm($c['ts']);
  if ($hm === '09:15') { $pick = $c; $ts_used = $c['ts']; break; }
}
if ($pick === null) {
  foreach ($candles as $c) {
    $hm = ts_to_ist_hm($c['ts']);
    if ($hm >= '09:15') { $pick = $c; $ts_used = $c['ts']; break; }
  }
}

if ($pick === null || $pick['open'] === null) {
  echo json_encode(['open'=>null, 'note'=>'no candle at/after 09:15 IST for '.$date]);
  exit;
}

echo json_encode(['open'=>$pick['open'], 'ts_used'=>$ts_used]);
