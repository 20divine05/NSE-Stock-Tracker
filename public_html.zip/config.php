<?php
// ----- TEMP: show errors while debugging (turn off later) -----
ini_set('display_errors', 1);
error_reporting(E_ALL);
// ---------------------------------------------------------------

// ...
// Secret key for gated registration (change this!)
if (!defined('REGISTER_SECRET')) {
    define('REGISTER_SECRET', 'lion'); // ← set your own random key
}
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); // throw exceptions

// TODO: set these to your Hostinger MySQL details from hPanel
$DB_HOST = "localhost";     // often 'localhost' on Hostinger
$DB_USER = "u713702417_lion1";  // example; yours will be different
$DB_PASS = "3*C3V!SlDepW";
$DB_NAME = "u713702417_lion"; // example; yours will be different

try {
    $mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
    $mysqli->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    // Log the exact error to server logs, show friendly text to user
    error_log("DB connect failed: " . $e->getMessage());
    http_response_code(500);
    die("Internal error: database connection failed.");
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
